---
name: Smart Commerce System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  mono-num:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an ultra-refined, high-precision retail paradigm engineered for frictionless, rapid digital checkout. It balances collegiate energy with enterprise-grade fintech reliability. 

### Aesthetic Movement
Modern Minimalist meets Crisp Swiss Utility. The system prioritizes functional clarity through generous negative space, purposeful contrast ratios, micro-interactions with immediate feedback, and structural geometric stability. Visual noise is aggressively eliminated to elevate inventory content, cart telemetry, and transaction states.

### Emotional Target
- **Instant Confidence:** High-contrast neutral typography and deliberate micro-copy evoke precision and trust.
- **Velocity & Flow:** Light surfaces, deliberate keylines, and fluid spatial cues minimize friction during high-frequency shopping workflows.
- **Refinement:** Soft radii combined with subtle ambient luminescence create a tactile, polished physical-digital parity.

## Colors

The palette establishes crisp typographic clarity against luminous surface layers, enriched by high-saturation status signals.

### Roles & Semantic Applications

- **Canvas & Surfaces:**
  - Base Background: `#FFFFFF` (pure white for main canvas layers)
  - Surface Substrate: `#F8FAFC` (slate-tinted background for structural contrast)
  - Elevated Container: `#FFFFFF` with `#E2E8F0` hairline boundary
  - Subtle Inset / Input Well: `#F1F5F9`

- **Typography & Content:**
  - Primary Content / Headers: `#0F172A` (deep slate navy, minimum 13:1 contrast against `#FFFFFF`)
  - Secondary / Body Text: `#1E293B`
  - Subtle / Metadata / Disabled: `#64748B`

- **Primary Interactive Brand:**
  - Brand Accent: `#2563EB` (vibrant royal blue for key calls-to-action, active indicators, cart totals)
  - Interactive Hover / Focus: `#1D4ED8`
  - Active Surface Highlight: `#EFF6FF` (tinted container for active selections)

- **Semantic Signals:**
  - Success / Inventory In-Stock: `#10B981` (emerald green)
  - Success Soft Container: `#ECFDF5`
  - Error / Cart Removal / Markdown Badges: `#F43F5E` (rose)
  - Warning / Stock Scarcity: `#F59E0B` (amber)

Never deploy pure black (`#000000`) for text or borders; tone density through the slate navy continuum to maintain warmth.

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for headers, marketing anchors, and numerical callouts with **Inter** for dense transactional UI data, checkout itemizations, and functional descriptions.

### Spatial Discipline
- **Tabular Numerals:** For price calculations, order subtotals, weight metrics, and real-time scanning tickers, enable tabular figures (`font-variant-numeric: tabular-nums`) within Inter to prevent horizontal layout shift during price re-computations.
- **Headings Tracking:** Apply negative tracking (`-0.01em` to `-0.03em`) on display sizes to yield a tight, editorial look.
- **Labels:** Button actions, tags, and badge counters use Plus Jakarta Sans at medium or semi-bold weights for rapid legibility at low sizes.

## Layout & Spacing

The architecture operates on an 8pt modular rhythm mapped through responsive fractional grids.

### Grid Framework
- **Desktop (>= 1200px):** 12-column layout, fixed max-width `1280px`, centered. Gutters set to `1.5rem` (`24px`), outer margins set to `3rem` (`48px`). The primary layout pairs an 8-column shopping/product view with a 4-column sticky Cart Sidebar.
- **Tablet (768px - 1199px):** 8-column layout. Gutters set to `1.5rem` (`24px`), outer margins set to `2rem` (`32px`). Cart transitions to an anchored bottom sheet or drawer trigger.
- **Mobile (<= 767px):** 4-column fluid layout. Gutters set to `1rem` (`16px`), outer margins set to `1rem` (`16px`). Full single-column reflow with persistent bottom navigation/checkout dock.

### Compositional Rules
- Keep interactive element touch targets at a minimum of `44x44px` across all form factors.
- Section paddings utilize `space-xl` internally to maintain an uncluttered visual pace.

## Elevation & Depth

Visual hierarchy uses ultra-subtle, light-diffused ambient shadows anchored by single-pixel boundaries to retain crispness on high-DPI displays.

### Depth Hierarchy
- **Level 0 (Flat):** Used for main canvas background (`#FFFFFF`, `#F8FAFC`). No shadow.
- **Level 1 (Structural Cards & Inventory Containers):** 
  - Border: `1px solid #E2E8F0`
  - Shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`
- **Level 2 (Hovered Cards, Dropdowns, Segmented Filters):** 
  - Border: `1px solid #CBD5E1`
  - Shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.05), 0 2px 4px -2px rgba(15, 23, 42, 0.03)`
- **Level 3 (Cart Drawer, Modals, Checkout Drawers):** 
  - Border: `1px solid #E2E8F0`
  - Shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`

### Glass & Overlay Accents
- Translucent sticky headers and checkout docks utilize backdrop blur: `background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(12px); border-bottom: 1px solid #E2E8F0;`.

## Shapes

The interface balances soft modern curves with structured alignments.

### Geometry Hierarchy
- **Primary Product Cards & Modals (`rounded-2xl`):** `1.5rem` (`24px`) radius for large surfaces to create a smooth, welcoming silhouette.
- **Standard Surfaces & Nested Panels (`rounded-xl`):** `1rem` (`16px`) radius for secondary containers, filter modules, and cart rows.
- **Interactive Elements (`rounded-lg`):** `0.5rem` (`8px`) to `0.75rem` (`12px`) radius for buttons, input bars, and quantity steppers to ensure distinct affordance.
- **Tags & Status Badges (`rounded-full`):** Full 9999px pills for stock badges, discount flags, and item count chips.

## Components

### Buttons
- **Primary:** Background `#2563EB`, text `#FFFFFF`, font `label-md`, radius `rounded-lg` (8px). Padding `12px 20px`. Hover: `#1D4ED8`. Active state scales subtly (`transform: scale(0.98)`).
- **Secondary / Subdued:** Background `#F1F5F9`, text `#0F172A`, border `1px solid #E2E8F0`. Hover: `#E2E8F0`.
- **Destructive:** Background `#F43F5E`, text `#FFFFFF`. Hover: `#E11D48`.
- **Cart Checkout (Hero CTA):** Full width, background `#2563EB`, flex container with price display aligned right and checkout text centered.

### Product & Cart Cards
- **Product Item Card:** Surface `#FFFFFF`, border `1px solid #E2E8F0`, radius `rounded-2xl`. Image container placed in `#F8FAFC` recessed well with `rounded-xl` interior margins. Hover elevates to Level 2 with transition timing `150ms ease-out`.
- **Cart Line Item:** Surface `#FFFFFF`, border-bottom `1px solid #F1F5F9`. Displays image thumbnail (64x64px, `rounded-lg`), title, inline weight/sku badge, numerical stepper, and live subtotal.

### Chips & Badges
- **Discount Badge:** Background `#FFF1F2`, text `#F43F5E`, border `1px solid #FFE4E6`, shape pill, typography `label-sm`.
- **Stock Chip (Available):** Background `#ECFDF5`, text `#059669`, border `1px solid #A7F3D0`, shape pill, typography `label-sm`.
- **Category Filter Chips:** Inactive: Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#1E293B`. Active: Background `#0F172A`, text `#FFFFFF`, border `1px solid #0F172A`.

### Form Inputs & Search Fields
- **Search Bar:** Height `48px`, background `#F8FAFC`, border `1px solid #E2E8F0`, radius `rounded-xl`, padding `0 16px`. Active focus shifts border to `#2563EB` and brings an inset ring `0 0 0 3px rgba(37, 99, 235, 0.15)`. Background shifts to `#FFFFFF`.

### Quantity Stepper
- Compact pill container (`#F1F5F9`), containing minus button, tabular numeric count, and plus button. Buttons use high-contrast micro-glyph icons with active press feedback.

### Checkbox & Radio Selection
- Unchecked: `18x18px`, border `2px solid #CBD5E1`, radius `6px` (checkbox) or `rounded-full` (radio), background `#FFFFFF`.
- Checked: Background `#2563EB`, border `#2563EB`, centered sharp white check/dot icon. Focus rings apply `3px rgba(37, 99, 235, 0.2)`.

### Live Scanner / RFID Status Indicator (Smart Cart Specific)
- Floating telemetry pill at the top of the interface: Translucent emerald or blue container indicating real-time cart connection status (`"Connected to Cart #04"`), with an active pulsing dot indicator (`#10B981`).